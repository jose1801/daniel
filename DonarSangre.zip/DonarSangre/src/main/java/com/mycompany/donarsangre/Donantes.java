/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.donarsangre;

/**
 *
 * @author PCFAMILIA
 */
public class Donantes {
    private int Cedula;
    private String apellidos;
    private String nombre;
    private String nacimiento;
    private String direccion;
    private int celular;
    private String correo;
    private String sangre;
    public Donantes(){
    }
    public Donantes(int Cedula, String apellidos, String nombre, String nacimiento, String direccion, int celular, String correo, String sangre){
        this.Cedula= Cedula;
        this.apellidos=apellidos;
        this.nombre=nombre;
        this.nacimiento=nacimiento;
        this.direccion=direccion;
        this.celular=celular;
        this.correo=correo;
        this.sangre=sangre;
    }
    public String getnombre() {
        return nombre;
    }

    public void setnombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCedula() {
        return Cedula;
    }

    public void setCedula(int Cedula) {
        this.Cedula = Cedula;
    }

    public String getapellidos() {
        return apellidos;
    }

    public void setapellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getnacimiento() {
        return nacimiento;
    }

    public void setfecha(String nacimiento) {
        this.nacimiento = nacimiento;
    }

    public String getdireccion() {
        return direccion;
    }

    public void setdireccion(String direccion) {
        this.direccion = direccion;
    }
    public int getcelular() {
        return celular;
    }

    public void setcelular(int celular) {
        this.celular = celular;
    }
    public String getcorreo() {
        return correo;
    }

    public void setcorreo(String correo) {
        this.correo = correo;
    }
    public String getsangre() {
        return sangre;
    }

    public void setsangre(String sangre) {
        this.sangre = sangre;
    }
    public void mostrarDona() {
        System.out.println("Cedula:" + this.Cedula);
        System.out.println("Nombre:" + this.nombre);
        System.out.println("Apellidos:" + this.apellidos);
        System.out.println("Nacimiento:" + this.nacimiento);
        System.out.println("Direccion:" + this.direccion);
        System.out.println("Celular:" + this.celular);
        System.out.println("Correo:" + this.correo);
        System.out.println("Tipo de sangre:" + this.sangre);
    }
}
