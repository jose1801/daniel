/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.donarsangre;

import java.util.ArrayList;
/**
 *
 * @author PCFAMILIA
 */
public class Campana {
    String nombreCam;
    String lugar;
    String fecha;
    String estado;
    private ArrayList<Personal>PERSONALES=new ArrayList<Personal>();
    private ArrayList<Donantes>Donante=new ArrayList<Donantes>();
    public Campana(){
    }
    public Campana(String nombreCam,String lugar,String fecha, String estado){
        this.nombreCam=nombreCam;
        this.lugar=lugar;
        this.fecha=fecha;
        this.estado=estado;
    }
    public String getnombreCam(){
        return nombreCam;
    }
    public void setnombreCam(String nombreCam){
        this.nombreCam=nombreCam;
    }
    public String getlugar(){
        return lugar;
    }
    public void setlugar(String lugar){
        this.lugar=lugar;
    }
    public String getfecha(){
        return fecha;
    }
    public void setfecha(String fecha){
        this.fecha=fecha;
    }
    public String getestado(){
        return estado;
    }
    public void setestado(String estado){
        this.estado=estado;
    }
    public void mostrarCam(){
        System.out.println("");
        System.out.println("CAMPAÑA:"+nombreCam);
        System.out.println("---------------------");
        System.out.println("Lugar:"+lugar);
        System.out.println("Fecha:"+fecha);
        System.out.println("Estado:"+estado);
        System.out.println("--------PERSONAL----------" );
        for (Personal per : PERSONALES){
            per.mostrarPer();
            System.out.println("");
        }
        System.out.println("-------------DONANTES------------" );
        for (Donantes dona : Donante){
            dona.mostrarDona();
            System.out.println("");
        }
    }
    public Personal buscarPer(int Cedula) {
        for (Personal perso : PERSONALES) {
            if (perso.getCedula()== Cedula) {
                return perso;
            }
        }
        return null;
    }
    public Donantes buscarDona(int Cedula) {
        for (Donantes dona : Donante) {
            if (dona.getCedula()== Cedula) {
                return dona;
            }
        }
        return null;
    }
    public void addCam(Personal objPersonales){
        this.PERSONALES.add(objPersonales);
    }
    public void adddona(Donantes objdon){
        this.Donante.add(objdon);
    }
    
}
