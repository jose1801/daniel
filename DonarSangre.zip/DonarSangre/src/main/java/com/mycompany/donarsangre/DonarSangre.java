/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.donarsangre;


import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author PCFAMILIA
 */
public class DonarSangre {
    
    public static Scanner scan = new Scanner(System.in).useDelimiter("\n");
    public static ArrayList<Campana> Campañas = new ArrayList<>();

    public static void main(String[] args) {
        int elec;
        do {
            elec = menu();
            operaciones(elec);
            System.out.println("Desea realizar otra operacion? (si|1|)");
            elec = scan.nextInt();
        } while (elec == 1);
    }
    public static int menu() {
        int op;
        do {
            System.out.println("****SISTEMA DE DONACION SANGRE****");
            System.out.println("1: Registrar Campaña");
            System.out.println("2: Registrar Personal");
            System.out.println("3: Listar Campaña");
            System.out.println("4: Registrar donantes");
            System.out.println("5: Listar Donantes");
            System.out.print("Elija la operacion: ");
            op = scan.nextInt();
            scan.nextLine();//fflush c++ para limpiar la memoria de ingreso
        } while (op < 1 || op > 5);
        return op;
    }

    public static void operaciones(int op) {
        switch (op) {
            case 1:
                RegistrarCampanas();
                break;
            case 2:
                RegistrarPersonal();
                break;
            case 3:
                
                break;
            case 4:
                RegistrarDonantes();
                break;
            case 5:
                fun_listar();
                break;
        }
    }

    public static void RegistrarCampanas() {
        String nombreCam;
        String lugar;
        String fecha;
        String estado;
        System.out.println("Ingrese el nombre de la Campaña: ");
        nombreCam = scan.nextLine();
        Campana objcam = buscarCam(nombreCam);
        if (objcam == null) {
            System.out.println("Ingrese el lugar: ");
            lugar = scan.nextLine();
            System.out.println("Ingrese la fecha de realizacion: ");
            fecha = scan.nextLine();
            System.out.println("Ingrese el estado(Acitva/Inactiva): ");
            estado = scan.nextLine();
            Campana objcampa = new Campana(nombreCam, lugar, fecha, estado);
            Campañas.add(objcampa);
        } else {
            System.out.println("Campaña ya ingresada anteriormente");
        }

    }

    public static Campana buscarCam(String nombreC) {
        for (Campana objP : Campañas) {
            if (objP.getnombreCam().equals(nombreC)) {
                return objP;
            }
        }
        return null;
    }

    public static void RegistrarPersonal() {
        int Cedula;
        String apellidos;
        String nombre;
        String nacimiento;
        String direccion;
        int celular;
        String correo;
        String usuario;
        String clave;
        System.out.println("Ingrese el nombre de la Campaña: ");
        String campa = scan.nextLine();
        Campana objcam = buscarCam(campa);
        if (objcam != null) {
            System.out.println("Ingrese el numero de cedula: ");
            Cedula = scan.nextInt();
            Personal objperso = objcam.buscarPer(Cedula);
            if (objperso == null) {
                scan.nextLine();
                System.out.println("Ingrese los apellidos: ");
                apellidos = scan.nextLine();
                System.out.println("Ingrese los nombres: ");
                nombre = scan.nextLine();
                System.out.println("Ingrese el lugar de nacimiento: ");
                nacimiento = scan.nextLine();
                System.out.println("Ingrese la direccion: ");
                direccion = scan.nextLine();
                System.out.println("Ingrese el numero de celular: ");
                celular = scan.nextInt();
                scan.nextLine();
                System.out.println("Ingrese el correo electronico: ");
                correo = scan.nextLine();
                System.out.println("Ingrese el usuario: ");
                usuario = scan.nextLine();
                System.out.println("Ingrese la clave: ");
                clave = scan.nextLine();
                Personal objpero = new Personal(Cedula,apellidos,nombre,nacimiento, direccion,celular,correo,usuario,clave);
                objcam.addCam(objpero);
            } else {
                System.out.println("Usuario ya ingresado anteriormente");
            }

        } else {
            System.out.println("No existe la Campaña ingresada");
        }
    }
    public static void RegistrarDonantes() {
        int Cedula;
        String apellidos;
        String nombre;
        String nacimiento;
        String direccion;
        int celular;
        String correo;
        String sangre;
        System.out.println("Ingrese el nombre de la Campaña: ");
        String campa = scan.nextLine();
        Campana objcam = buscarCam(campa);
        if (objcam != null) {
            System.out.println("Ingrese el numero de cedula: ");
            Cedula = scan.nextInt();
            Donantes objdona = objcam.buscarDona(Cedula);
            if (objdona == null) {
                scan.nextLine();
                System.out.println("Ingrese los apellidos: ");
                apellidos = scan.nextLine();
                System.out.println("Ingrese los nombres: ");
                nombre = scan.nextLine();
                System.out.println("Ingrese el lugar de nacimiento: ");
                nacimiento = scan.nextLine();
                System.out.println("Ingrese la direccion: ");
                direccion = scan.nextLine();
                System.out.println("Ingrese el numero de celular: ");
                celular = scan.nextInt();
                scan.nextLine();
                System.out.println("Ingrese el correo electronico: ");
                correo = scan.nextLine();
                System.out.println("Ingrese el tipo de sangre: ");
                sangre = scan.nextLine();
                Donantes objdon = new Donantes(Cedula,apellidos,nombre,nacimiento, direccion,celular,correo,sangre);
                objcam.adddona(objdon);
            } else {
                System.out.println("Donante ya ingresado anteriormente");
            }

        } else {
            System.out.println("No existe la Campaña ingresada");
        }
    }
    public static void fun_listar(){
    for (Campana objcam : Campañas){
        objcam.mostrarCam();
    System.out.println("");
        }
    }
}
